/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Rajesh
 */
public class paymentpojo {
    public int insert(String Emailid, String Date, String Seat, String Showtime, String Price) throws SQLException, ClassNotFoundException {
        
             String qu="insert into TICKETS values(?,?,?,?,?)";
              Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection con=DriverManager.getConnection("jdbc:derby://localhost:1527/PARK", "PARK", "PARK");
             PreparedStatement ps=con.prepareStatement(qu);
            
             ps.setString(1, Emailid);
             ps.setString(2, Date);
             ps.setString(3, Seat);
             ps.setString(4, Showtime);
             ps.setString(5, Price);
              
             int r=ps.executeUpdate();
       
              if(r==1) 
            {
                return r;
            }
            else{
                return r;
            }
          
    }
    
}

    
