/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Rajesh
 */
public class signuppojo {

    public int insert(String mobile, String fn, String ln, String Emailid, String password) throws ClassNotFoundException, SQLException {
        
             String qu="insert into USERDATA values(?,?,?,?,?)";
              Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection con=DriverManager.getConnection("jdbc:derby://localhost:1527/PARK", "PARK", "PARK");
             PreparedStatement ps=con.prepareStatement(qu);
            
             ps.setString(1, fn);
             ps.setString(2, ln);
             ps.setString(3, Emailid);
             ps.setString(4, password);
              ps.setString(5, mobile);
             int r=ps.executeUpdate();
            if(r==1) 
            {
                return r;
            }
            else{
                return r;
            }
             

    }
    public static String user(String emailid) throws ClassNotFoundException, SQLException{
       
      String name=null;
                Class.forName("org.apache.derby.jdbc.ClientDriver");
               Connection c=DriverManager.getConnection("jdbc:derby://localhost:1527/PARK","PARK","PARK");

              String command="select * from USERDATA where EMAILID=?";
              PreparedStatement ps=c.prepareStatement(command);
              ps.setString(1,emailid);
             ResultSet rs=ps.executeQuery();
             if(rs.next())
             name=rs.getString(1);
             System.out.println(name);
              return name;
  }

    
}
