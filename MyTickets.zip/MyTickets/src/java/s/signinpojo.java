/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package s;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Rajesh
 */
public class signinpojo {
     public static boolean check(String Emailid,String password) throws SQLException {
         boolean st=false;
        try
        {
            String qu="select * from USERDATA where EMAILID=? and PASSWORD=?";
             Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection con=DriverManager.getConnection("jdbc:derby://localhost:1527/PARK", "PARK", "PARK");
             PreparedStatement ps=con.prepareStatement(qu);
             ps.setString(1, Emailid);
             ps.setString(2, password);
              
              ResultSet rs=ps.executeQuery();
             st=rs.next();
             
               }catch( ClassNotFoundException | SQLException e){
               }
        
         return st;
        
     }
 public static String user(String emailid) throws ClassNotFoundException, SQLException{
       
      String name=null;
                Class.forName("org.apache.derby.jdbc.ClientDriver");
               Connection c=DriverManager.getConnection("jdbc:derby://localhost:1527/PARK","PARK","PARK");

              String command="select * from USERDATA where EMAILID=?";
              PreparedStatement ps=c.prepareStatement(command);
              ps.setString(1,emailid);
             ResultSet rs=ps.executeQuery();
             if(rs.next())
             name=rs.getString(1);
             System.out.println(name);
              return name;
  }

        
     }
    

