/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import s.paymentpojo;

/**
 *
 * @author Rajesh
 */
public class payments extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * @throws java.sql.SQLException
     * @throws java.lang.ClassNotFoundException
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException, ClassNotFoundException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            HttpSession session=request.getSession();
             String Date=(String)session.getAttribute("date");
                 String Seat=(String)session.getAttribute("seat");
                 String Showtime=(String)session.getAttribute("showtime");
                 String Price=(String)session.getAttribute("price");
                     String Emailid=(String)session.getAttribute("emailid");   
                       paymentpojo pay=new paymentpojo();
              pay.insert(Emailid,Date,Seat,Showtime,Price);

            String bank=request.getParameter("bank");
            if(bank.compareTo("canara")==0)
            {
             String canara="CANARA BANK";
             
             session.setAttribute("canara1", canara);
             
              String card=request.getParameter("card");
            if(card.compareTo("credit")==0){
                System.out.println(canara);
                 System.out.println("<h1>ENTER UR CREDIT CARD DETAILS<h1>");
             RequestDispatcher rd=request.getRequestDispatcher("creditcard.jsp");
             rd.include(request, response);
            }
            else{
                System.out.println(canara);
                System.out.println("<h1>ENTER UR DEBIT CARD DETAILS<h1>");
                RequestDispatcher rd=request.getRequestDispatcher("debitcard.jsp");
             rd.include(request, response);
                
            }
            }
             if(bank.compareTo("kotak")==0)
            {
             String kotak="KOTAK";
            
             session.setAttribute("kotak1", kotak);
            
             String card=request.getParameter("card");
            if(card.compareTo("credit")==0){
                 System.out.println(kotak);
                 System.out.println("<h1>ENTER UR CREDIT CARD DETAILS<h1>");
             RequestDispatcher rs=request.getRequestDispatcher("creditcard.jsp");
             rs.include(request, response);
            }
            else{
                 System.out.println(kotak);
                 System.out.println("<h1>ENTER UR DEBIT CARD DETAILS<h1>");
             RequestDispatcher rs=request.getRequestDispatcher("debitcard.jsp");
             rs.include(request, response);
            }  }
            if(bank.compareTo("hdfc")==0)
            {
             String hdfc="HDFC";
            
             session.setAttribute("hdfc1", hdfc);
            
             String card=request.getParameter("card");
            if(card.compareTo("credit")==0){
                 System.out.println(hdfc);
                 System.out.println("<h1>ENTER UR CREDIT CARD DETAILS<h1>");
             RequestDispatcher rs=request.getRequestDispatcher("creditcard.jsp");
             rs.include(request, response);
            }
            else{
                System.out.println(hdfc);
                System.out.println("<h1>ENTER UR DEBIT CARD DETAILS<h1>");
             RequestDispatcher rs=request.getRequestDispatcher("debitcard.jsp");
             rs.include(request, response);
            }  
            }
                        
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(payments.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(payments.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
